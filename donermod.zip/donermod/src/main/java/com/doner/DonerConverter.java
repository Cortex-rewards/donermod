package com.doner;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DonerConverter {
    // $300M, $1.5B, $250K, $1,500,000 gibi değerleri yakalar.
    // Scoreboard'da "$" yoksa regex'in başındaki \\$ kısmını (\\$?) yap.
    private static final Pattern PATTERN =
        Pattern.compile("\\$(\\d{1,3}(?:,\\d{3})+|\\d+)(\\.\\d+)?([KkMmBbTt])?(?![A-Za-z])");

    private static final BigDecimal UNIT = new BigDecimal("100000000"); // 100M = 1 döner
    private static final BigDecimal MIN = new BigDecimal("0.01");
    private static final String ICON = "\uE000"; // font/default.json'daki döner karakteri
    private static final DecimalFormat FMT =
        new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));

    private DonerConverter() {}

    private static BigDecimal multiplier(String s) {
        if (s == null) return BigDecimal.ONE;
        return switch (Character.toUpperCase(s.charAt(0))) {
            case 'K' -> new BigDecimal("1000");
            case 'M' -> new BigDecimal("1000000");
            case 'B' -> new BigDecimal("1000000000");
            case 'T' -> new BigDecimal("1000000000000");
            default -> BigDecimal.ONE;
        };
    }

    public static String convert(String text) {
        if (text == null || text.indexOf('$') < 0) return text;
        Matcher m = PATTERN.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String repl = m.group();
            try {
                String num = m.group(1).replace(",", "") + (m.group(2) == null ? "" : m.group(2));
                BigDecimal value = new BigDecimal(num).multiply(multiplier(m.group(3)));
                BigDecimal doner = value.divide(UNIT, 4, RoundingMode.HALF_UP);
                // 0.01 döneri bile geçmeyen küçük paralar olduğu gibi kalır
                if (doner.compareTo(MIN) >= 0) {
                    repl = FMT.format(doner) + ICON;
                }
            } catch (Exception ignored) {}
            m.appendReplacement(sb, Matcher.quoteReplacement(repl));
        }
        m.appendTail(sb);
        return sb.toString();
    }
}
