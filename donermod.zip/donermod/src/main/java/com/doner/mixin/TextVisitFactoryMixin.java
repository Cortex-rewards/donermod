package com.doner.mixin;

import com.doner.DonerConverter;
import net.minecraft.text.TextVisitFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

// Ekrana çizilen (ve genişliği ölçülen) tüm yazılar buradan geçer:
// scoreboard, ah, tooltip, chat, tab...
@Mixin(TextVisitFactory.class)
public class TextVisitFactoryMixin {
    @ModifyVariable(
        method = "visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
        at = @At("HEAD"),
        argsOnly = true
    )
    private static String doner$convert(String text) {
        return DonerConverter.convert(text);
    }
}
